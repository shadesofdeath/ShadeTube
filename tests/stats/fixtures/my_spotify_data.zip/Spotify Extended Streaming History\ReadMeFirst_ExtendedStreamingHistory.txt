Synthetic test data for ShadeTube's stats_test (not real listening history).
